<?php
// SMSLink Application Version Definition
if (!defined('APP_VERSION')) {
    define('APP_VERSION', 'v1.0.0');
}
if (!defined('APP_BUILD_DATE')) {
    define('APP_BUILD_DATE', '2026-09-05');
}
if (!defined('APP_REPO')) {
    define('APP_REPO', 'beingniloy/smslink');
}
return [
    'version' => APP_VERSION,
    'build_date' => APP_BUILD_DATE,
    'repo' => APP_REPO
];
